package composicion;

public class Torres {
    private  String tipo;
    private  int vida;
    public Torres(String tipo,int vida){
        this.tipo=tipo;
        this.vida=vida;
    }

    public String getTipo() {
        return tipo;
    }

    public int getVida() {
        return vida;
    }
    @Override
    public String toString(){
        return "Torre"+tipo+"vida"+vida;
    }
}
