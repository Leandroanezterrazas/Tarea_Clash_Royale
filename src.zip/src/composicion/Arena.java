package composicion;

import java.util.ArrayList;
import java.util.List;

public class Arena {
    private String nombre;
    private List<Torres>torres;
    public Arena(String nombre){
        this.nombre=nombre;
        this.torres=new ArrayList<>();
        torres.add(new Torres("Rey",5000));
        torres.add(new Torres("Reina Arquera Izquierda",2500));
        torres.add(new Torres("Reina Arquera Derecha",2500));
    }
    public void mostrarTorre(){
        System.out.println("Arena"+nombre);
        for (Torres t:torres){
            System.out.println("-"+t);
        }
    }

    public static void main(String[] args) {
        Arena arena=new Arena("Arena Montapuerco");
    }
}
