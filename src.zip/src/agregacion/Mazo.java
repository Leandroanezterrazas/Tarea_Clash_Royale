package agregacion;

import java.util.ArrayList;
import java.util.List;

public class Mazo {
    private String nombreMazo;
    private List<Carta>cartas;
    public Mazo(String nombreMazo){
        this.nombreMazo=nombreMazo;
        this.cartas=new ArrayList<>();
    }
    public void agregarCartas(Carta carta){
        cartas.add(carta);
    }
    public void mostrarCartas(){
        System.out.println("Agregacion.Mazo:"+nombreMazo);
        if (cartas.isEmpty()){
            System.out.println("Este mazo no tiene cartas ");
        }else {
            for (Carta c:cartas){
                System.out.println("-"+c);
            }
        }
    }

    public void agregarCarta(Carta montapuercos) {
    }
}
