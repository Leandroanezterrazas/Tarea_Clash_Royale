package agregacion;

public class Carta {
    private String nombre;
    private int elixir;
    public Carta(String nombre,int elixir){
        this.nombre=nombre;
        this.elixir=elixir;
    }

    public String getNombre() {
        return nombre;
    }

    public int getElixir() {
        return elixir;
    }
    @Override
    public String toString(){
        return nombre+"Costo"+elixir+"elixir";
    }

    public static void main(String[] args) {
        Carta montapuercos = new Carta("Montapuercos", 4);
        Carta bolaDeFuego = new Carta("Bola de Fuego", 4);
        Carta esbirros = new Carta("Esbirros", 3);
        Mazo mazo1 = new Mazo("Ofensivo");
        Mazo mazo2 = new Mazo("Defensivo");
        mazo1.agregarCarta(montapuercos);
        mazo1.agregarCarta(bolaDeFuego);
        mazo2.agregarCarta(bolaDeFuego);
        mazo2.agregarCarta(esbirros);
        mazo1.mostrarCartas();
        System.out.println();
        mazo2.mostrarCartas();
        System.out.println("Carta independiente: " + montapuercos);
    }
}
