package dependencia;

public class Jugador {
    private  String nombre;
   public Jugador(String nombre){
       this.nombre=nombre;
   }
   public  void usarCarta(Carta carta){
       System.out.println("Jugador"+nombre+"uso de carta"+carta.getNombre()+"en batalla");

   }
    public static void main(String[] args) {
        Jugador jugador1=new Jugador("Pepe");
        Carta montapuercos=new Carta("Montapuercos",4);
        Carta bolaDeFuego=new Carta("Bola de fuego",4);
    }
}
