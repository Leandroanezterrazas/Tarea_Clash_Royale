package dependencia;

public class Carta {
    private String nombre;
    private int elixir;
    public Carta(String nombre,int elixir){
        this.nombre=nombre;
        this.elixir=elixir;
    }

    public String getNombre() {
        return nombre;
    }

    public int getElixir() {
        return elixir;
    }
}
