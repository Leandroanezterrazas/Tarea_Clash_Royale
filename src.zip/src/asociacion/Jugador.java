package asociacion;

public class Jugador {
    private String nombre;
    private int nivel;
    public Jugador(String nombre,int nivel){
        this.nombre=nombre;
        this.nivel=nivel;
    }

    public String getNombre() {
        return nombre;
    }

    public int getNivel() {
        return nivel;
    }
    @Override
    public String toString(){
        return "jugador"+nombre+"nivel"+nivel;
    }
}
