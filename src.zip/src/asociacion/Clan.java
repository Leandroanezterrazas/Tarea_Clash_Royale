package asociacion;

import agregacion.Mazo;
import dependencia.Carta;

import java.util.ArrayList;
import java.util.List;

public class Clan {
    private String nombreClan;
    private List<Jugador>jugadores;
    public Clan(String nombreClan){
        this.nombreClan=nombreClan;
        this.jugadores=new ArrayList<>();
    }
    public  void agregarJugadores(Jugador jugador){
        jugadores.add(jugador);
    }
    public void mostrarJugadores(){
        System.out.println("Asociacion.Clan:"+nombreClan);
        if(jugadores.isEmpty()){
            System.out.println("Aun no hay jugadores en este clan");
        }else {
            for (Jugador j:jugadores){
                System.out.println();
            }
        }
    }
    public static void main(String[] args) {
        agregacion.Carta montapuercos= new agregacion.Carta("Montapuercos",4);
        agregacion.Carta megacaballero= new agregacion.Carta("Megacaballero",6);
        Mazo mazo1=new Mazo("Ofensivo");
        Mazo mazo2=new Mazo("Defensivo");
        mazo1.agregarCartas(montapuercos);
        mazo2.agregarCartas(megacaballero);

    }
}
